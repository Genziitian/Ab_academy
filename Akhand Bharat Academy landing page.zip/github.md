repo: Genziitian/Ab_academy
branch: main
path: EdTech Platform Website Redesign

## Last sync
date: 2026-11-02T15:49:08Z

### Updated in this project
- Imported current Home, SiteHeader, SiteFooter and hero/feature images
- Exploring new landing page directions for Akhand Bharat Academy

## Screen map
| Screen | Repo files |
|---|---|
| Home (current) | EdTech Platform Website Redesign/Home.dc.html |
| SiteHeader / SiteFooter | EdTech Platform Website Redesign/SiteHeader.dc.html, SiteFooter.dc.html |
| Images | apps/web/public/images/*.png |
